Steps to run the code:
-----------------------------------------------
0. 'median_logn.c' contains C code for the given problem.

1. compile 'median_logn.c' using gcc compiler.
   e.g

  # gcc median_logn.c

2. this should create an executable 'a.out' file.

3. run the executable giving the input file as argument.
	e.g

   # ./a.out input.txt
-------------------------------------------------
