/*
 * Name: Abhishek Goswami
 * Date: 3/7/2011
 * Pb  : Median of Arrays Pb
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<limits.h>

/* macro to limit size of line buffer */
#define LINE_LENGTH_MAX 1000

/* keeping to macro to determine max array size */
#define ARRAY_SIZE_MAX 100

/* sentinel value to mark end of array */
#define PSEUDO_INFINITY INT_MAX

int main( int argc, char *argv[]) {
	
	FILE *fp;
	char line[LINE_LENGTH_MAX];
	char *c;
	int A[ARRAY_SIZE_MAX + 1], B[ARRAY_SIZE_MAX + 1]; /* + 1 to accommmodate sentinel value */
	int a_size = 0, b_size = 0;
	int i, j, total_size, median_index, count;
	
	double median;
	int x, y;

	fp = fopen(argv[1], "r");
	if(fp == NULL) {
		printf("Cannot open file. Exiting\n"); fflush(stdout);
		return 1;
	}
	
	/* getting array A elements from file*/

	memset(line, 0, sizeof(line));
	fgets(line, LINE_LENGTH_MAX, fp); 
	c = strtok( line, "=");
	
	while ( (c = strtok( NULL, ",")) != NULL ) {
		A[a_size++] = atoi(c);
		if( a_size > ARRAY_SIZE_MAX ) {
			printf("Array Size Exceeded. Exiting\n"); fflush(stdout);
			fclose(fp);
			return 1;
		}
	}
	A[a_size] = PSEUDO_INFINITY;

	/* getting array B elements from file */
	
	memset(line, 0, sizeof(line));
	fgets(line, LINE_LENGTH_MAX, fp); 
	c = strtok( line, "=");
	while ( (c = strtok( NULL, ",")) != NULL ) {
		B[b_size++] = atoi(c);
		if( b_size > ARRAY_SIZE_MAX ) {
			printf("Array Size Exceeded. Exiting\n"); fflush(stdout);
			fclose(fp);
			return 1;
		}
	}
	B[b_size] = PSEUDO_INFINITY;

	fclose(fp);
	
	printf("\nArray A elements\n");
	for( i = 0; i < a_size; i++)
		printf("A[%d]=%d\n", i, A[i]);

	printf("\nArray B elements\n");
	for( i = 0; i < b_size; i++)
		printf("B[%d]=%d\n", i, B[i]);


	total_size = a_size + b_size;
	median_index = (total_size + 1) / 2;

	i = j = 0;
	count = 1;
	while ( count < median_index ) {
		if( A[i] <= B[j] ) {
			i++;
		}
		else {
			j++;
		}
		count++;
	}

	if( (total_size % 2) == 1 ) {
		median = ( A[i] <= B[j] ) ? A[i] : B[j];
	} else {
		x = ( A[i] <= B[j] ) ? A[i++] : B[j++];
		y = ( A[i] <= B[j] ) ? A[i] : B[j];
		median = ( x + y ) / 2.0;
	}

	printf("\n\nMedian of A and B is : %f\n\n\n", median);	
	return 1;
}
